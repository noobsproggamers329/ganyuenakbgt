#!/bin/sh
./noa -a ethash -o stratum+tcp://daggerhashimoto.usa-east.nicehash.com:3353 -u 3FF3GWGcjPqpJ1Wd6JpLPFLPtvQLHYAHZC -p x -w rafizkangmining --low-load 1
